import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 2},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000\u001a\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\u001a\"\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00012\b\b\u0002\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b\u001a\u0006\u0010\n\u001a\u00020\u0005\u001a\u0006\u0010\u000b\u001a\u00020\u0005\u001a\u0006\u0010\f\u001a\u00020\u0005\"\u0011\u0010\u0000\u001a\u00020\u00018F¢\u0006\u0006\u001a\u0004\b\u0002\u0010\u0003"},
   d2 = {"nb", "LNiubi;", "getNb", "()LNiubi;", "invokeA", "", "o", "p", "", "q", "invokeB", "invokeC", "invokeD"}
)
public final class SomethingKt {
   @NotNull
   public static final Niubi getNb() {
      return new Niubi(3, 5);
   }

   public static final void invokeA(@NotNull Niubi o, int p, int q) {
      Intrinsics.checkNotNullParameter(o, "o");
      int var3 = o.getI() + o.getJ() + p + q;
      boolean var4 = false;
      System.out.println(var3);
   }

   // $FF: synthetic method
   public static void invokeA$default(Niubi var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var0 = getNb();
      }

      if ((var3 & 2) != 0) {
         var1 = 1;
      }

      invokeA(var0, var1, var2);
   }

   public static final void invokeB() {
      invokeA$default((Niubi)null, 0, 8, 3, (Object)null);
   }

   public static final void invokeC() {
      invokeA$default((Niubi)null, 3, 4, 1, (Object)null);
   }

   public static final void invokeD() {
      invokeA(new Niubi(10086, 10087), 10010, 10000);
   }
}
