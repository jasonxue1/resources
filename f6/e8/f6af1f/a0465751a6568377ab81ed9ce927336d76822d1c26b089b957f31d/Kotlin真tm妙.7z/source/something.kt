/*
 * Copyright (c) 2021 teddyxlandlee, All right reserved.
 * 
*/

class Niubi(val i: Int, val j: Int)

val nb
	get() = Niubi(3, 5)

fun invokeA(o: Niubi = nb, p: Int = 1, q: Int) : Unit{
	println( o.i + o.j + p + q )
}

fun invokeB() {
	invokeA(q = 8)
}

fun invokeC() {
	invokeA(p = 3, q = 4)
}

fun invokeD() {
	invokeA(Niubi(10086, 10087), 10010, 10000)
}