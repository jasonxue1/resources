package b.a;

import java.util.Map;
import a.b.Alpha;

public class Beta {
	private final Alpha alpha = new Alpha(Map.of("###", 114514));
	private static final Beta INSTANCE = new Beta();
	public static Beta getInstance() {
		return INSTANCE;
	}

	@Override
	public String toString() {
		return "Beta{alpha=" + alpha +
				'}';
	}
}