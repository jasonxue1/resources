package a.b;

import static java.util.Objects.requireNonNull;
import java.util.Map;

public class Alpha {
	private final Map<String, Object> args;

	public Map<String, Object> getArgs() {
		return args;
	}

	public Alpha(Map<String, Object> m) {
		this.args = requireNonNull(m);
	}

	public String toString() {
		return "Alpha " + getArgs();
	}
}