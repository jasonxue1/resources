package fuck;

import a.b.Alpha;
import b.a.Beta;
import java.util.Map;
import java.util.Collections;
import java.util.HashMap;
import java.lang.reflect.*;

class FuckedAlpha extends Alpha {
	FuckedAlpha(Map<String, Object> m) {
		super(m);
	}

	FuckedAlpha(Alpha alpha) {
		this(alpha.getArgs());
	}

	@Override
	public Map<String, Object> getArgs() {
		Map<String, Object> m = new HashMap<>(super.getArgs());
		m.put("Fucked", Boolean.TRUE);
		return Collections.unmodifiableMap(m);
	}
}

public class Fuck {
	public static void main(String... args) {
		Beta beta = Beta.getInstance();
		try {
			Class<?> clazz = beta.getClass();
			//Field field = clazz.getField("alpha");	-> NoSuchFieldException
			Field field = clazz.getDeclaredField("alpha");
			field.setAccessible(true);
			Alpha alpha = (Alpha) field.get(beta);
			System.out.println(alpha);

			field.set(beta, new FuckedAlpha(alpha));
			System.out.println(field.get(beta));
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
}